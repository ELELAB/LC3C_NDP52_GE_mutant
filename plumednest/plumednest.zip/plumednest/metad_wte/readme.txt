#Here we include the files to reproduce the metaD simulation with the CHARMM22star force field and
the TIPS3P water model performed using GROMACS 2019.4 and PLUMED 2.5.3

Di Rita A, Angelini DF, Maiorino T, Caputo V, Cascella R, Kumar M, Tiberti M,
Lambrughi M, Wesch N, Löhr F, Dötsch V, Carinci M, D'Acunzo P, Chiurchiù V,
Papaleo E, Rogov VV, Giardina E, Battistini L, Strappazzon F. Characterization
of a natural variant of human NDP52 and its functional consequences on
mitophagy. Cell Death Differ. 2021 Aug;28(8):2499-2516. doi:
10.1038/s41418-021-00766-3.

#We copied the plumed.dat reference.pdb and sim.tpr from the OSF repository https://osf.io/48wzq/
#in which the metaD simulation is stored
