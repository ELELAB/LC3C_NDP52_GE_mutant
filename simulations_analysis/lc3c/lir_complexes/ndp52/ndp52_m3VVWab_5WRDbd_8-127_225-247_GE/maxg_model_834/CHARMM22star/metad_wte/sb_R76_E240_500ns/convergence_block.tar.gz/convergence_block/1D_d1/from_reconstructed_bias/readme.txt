This directory implements the block error analysis for free energy in MetaD 
simulations. It requires

* a colvar file with the metad.bias. In this example we consider the case in
which the bias is reconstructed after having done the calculation.
* a directory in which fes files calculated using sum_hills are stored, so that
the FES can be compared with the one coming out of this analysis
* the .py and .pnl scripts in this directory, for running the analysis
and plotting

We have provided a simple scripts that runs the whole analysis.
*NOTE* that this script will likely need to be revised according to
the case of study, see the script comments for details

you can just run it as follows:

bash block_analysis.sh


