#use block error method for convergence

#the colvar file can be used since it includes the bias to be read


#you can use the sh script block_analysis.sh to run the analysis - might take few minutes

#do not use the script without revising it to your own case study
#N.B. for kT either use 2.5 if it is a good approximation or if you want an exact calculation:
#  kT = tempK*0.0083144598 (where tempK is the temperature set in the plumed.dat file for your simulation)


./block_analysis.sh

#the script uses the gnuplot script to plot the results (customize it to your case study if needed before running)

#you need to have in your folder also the do_block_fes.py  which handles the fes analysis

#check in the final fes file (in our case fes_500.dat) if you get infinity values and in case rerun refining the min
and max value for the grid

#in our case we started with 0.1-2.0 as in the plumed.dat file but then narrowed down to 0.25-1.8 

#check if there are residual infinity values and copy the final fes to a new file where you can remove them in vim 
#using 1,$ /Infinity/d

cp fes.500.dat  fes.500.noinf.dat

#with the script  plot_fes_compare.py you can compare the final fes calculated here with the original one

python plot_fes_compare.py

#if they are different you might want to try to re-estimate the weights (see folder ../recounst) 
