import numpy as np
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt
import sys

#read the fes from the simulation and the one from the block analysis - they should be similar
fes_ours = '../../../../../../../../../../../../simulations/lc3c/lir_complexes/ndp52/ndp52_m3VVWab_5WRDbd_8-127_225-247_GE/maxg_model_834/CHARMM22star/metad_wte/sb_R76_E240_500ns/1D_d1/fes_500.dat'
fes_blocks='fes.500.noinf.dat'

data_blocks = np.genfromtxt(sys.argv[1], usecols=(0,1,2), invalid_raise=False).T
data_ours = np.loadtxt(sys.argv[2]).T

data_ours[1] = data_ours[1] / 4.184
data_blocks[1] = (data_blocks[1] - np.min(data_blocks[1])) / 4.184

plt.plot(data_ours[0], data_ours[1], label='sum_hills FES (500)')
plt.plot(data_blocks[0], data_blocks[1], label='block analysis FES (500)')
plt.ylabel('Free energy (kcal/mol)')
plt.xlabel("CV (nm)")
plt.ylim(0,10)
plt.xlim(0.2, 1.8)
plt.legend()
plt.savefig('fes_compare.pdf')
