#!/bin/bash
#use block error method for convergence
. /usr/local/envs/py37/bin/activate

#variables to be defined

# simulations directory
PATHdata="../../../../../../../../../../../../simulations/lc3c/lir_complexes/ndp52/ndp52_m3VVWab_5WRDbd_8-127_225-247_GE/maxg_model_834/CHARMM22star/metad_wte/sb_R76_E240_500ns"
colvar=$PATHdata/colvar

fes_dir=../../../1D_d1/
#define the block size
start_size=1000
end_size=150000
delta_size=1000

# check column numbers for cv and bias (col 3 is bias in this case -replace it if you have a different colvar)
# find maximum bias value
bmax=$(awk 'BEGIN{max=0.}{if($1!="#!" && $3>max)max=$3}END{print max}' ${colvar})
echo "max bias is" ${bmax}

# estimate weights
# print cv d1 values and estimate weights 
awk '{if($1!="#!") print $2,exp(($3-bmax)/kbt)}' kbt=2.5 bmax=$bmax ${colvar} > d1.weight

# perform block analysis
rm -f err.blocks
rm -f fes.*.dat

# for each block size
for i in $(seq ${start_size} ${delta_size} ${end_size}); do
        echo "doing block size ${i}"
        # calculate error and plot fes
	#cv+weight file, number of cvs for fes, min and max grid, number of bin, KBT, block number
	python3 do_block_fes.py d1.weight 1 0.25 1.8 151 2.477 $i
        echo $i $(awk '{tot+=$3}END{print tot/NR}' fes.$i.dat) >> err.blocks
	gnuplot  -e "fes=${i}"  plot_fes.pnl
done
gnuplot plot.pnl
python plot_fes_compare.py fes.${i}.dat ${fes_dir}/fes_${i}.dat
