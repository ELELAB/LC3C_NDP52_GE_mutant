#!/bin/bash

# load your environment
. /usr/local/envs/py37/bin/activate
module load plumed

# setting data variables
PATHdata="../../../../../../../../../../simulations/lc3c/lir_complexes/ndp52/ndp52_m3VVWab_5WRDbd_8-127_225-247_GE/maxg_model_834/CHARMM22star/metad_wte/sb_R76_E240_500ns"
traj=${PATHdata}/Mol_An/center_traj.xtc
ref_pdb=${PATHdata}/reference.pdb
hills=${PATHdata}/HILLS

# copy or link here files that need to be local.
# we create a copy of the HILLS file because we don't want to risk messing
# up the original in case there's a mistake in the plumed file.


# copying over or linking other files might be necessary depending 
# on your plumed.dat
cp ${hills} .
ln -s ${ref_pdb} .
plumed driver --plumed plumed.dat --mf_xtc ${traj}
rm HILLS

