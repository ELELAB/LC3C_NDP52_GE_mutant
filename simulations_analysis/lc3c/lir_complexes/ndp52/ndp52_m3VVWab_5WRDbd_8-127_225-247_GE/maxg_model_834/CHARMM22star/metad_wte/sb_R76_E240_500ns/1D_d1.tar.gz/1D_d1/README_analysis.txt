#Check of metadynamics#

#source the gromacs+plumed version
source /usr/local/gromacs-5.1.2_plumed-2.3b/bin/GMXRC.bash 


#have MetaD_analysis in the folder and run for 1D  fes with 1000 stride
#to be done with ssh -X or -Y

tsp -N 1 nohup python MetaD_analysis_0.1.3.py -nt 1 -hills HILLS -colvar colvar -plot -pdf meta.pdf -plumed /usr/local/plumed-2.3b/bin/plumed -stride 1000 >& log &

#in case the plots have not been generated rerun MetaD_analysis for plotting only
python MetaD_analysis_0.1.3.py -n -colvar colvar -plumed /usr/local/plumed-2.3b/bin/plumed -stride 1000 -nt 1 -plot -pdf meta.pdf

#The HILLS and colvar file are located in the corresponding folder in the OSF repository associated with this publication
#The script MetaD_analysis_0.1.3.py can be supplied upon request

