#to estimate convergence we can calculate the differences in free energy between state of interest along d1
#to do so we need a symbolic link to the fes files calculated with stride 1000 and they need to be in this folder 
#TO REPLACE: the link below needs to be replaced if you run it on another system

for i in ../../../../../../../../../../../../simulations/lc3c/lir_complexes/ndp52/ndp52_m3VVWab_5WRDbd_8-127_225-247_GE/maxg_model_834/CHARMM22star/metad_wte/sb_R76_E240_500ns/1D_d1/fes_*.dat; do ln -s $i .; done

#run analyze_FES to get the ddGs estimate 
#./analyze_FES.sh NFES minA maxA minB maxB KBT
#we define the region salt-bridge formed from 0.3 (lower wall) to 0.7 nm (so the two minima which might have a formed salt-bridge are included) and then from 1.55 to 1.7 nm (upper wall)

./analyze_FES.sh 500 0.2 0.7 1.55 1.7 2.5 > d1_dGvstime.txt
#to plot the results one could use the gnuplot script in the folder plot_dGs.pnl
#or any other tool for figure preparation - remember to convert kj/mol to kcal/mol in the process

#current values for analyze_FES.sh:
./analyze_FES.sh 500 0.3 0.7 1.55 1.7 2.5 > d1_dGvstime.txt

