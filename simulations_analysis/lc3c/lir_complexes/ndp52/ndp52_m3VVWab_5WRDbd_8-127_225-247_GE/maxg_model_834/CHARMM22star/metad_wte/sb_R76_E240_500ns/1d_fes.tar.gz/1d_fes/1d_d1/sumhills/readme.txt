#visualize/explore final fes
# you need to be connected with ssh -X

#create symbolic link to the final fes

#TO REPLACE: the link below need to be replaced with the one of the system to use for analysis

ln -s ../../../../../../../../../../../../simulations/lc3c/lir_complexes/ndp52/ndp52_m3VVWab_5WRDbd_8-127_225-247_GE/maxg_model_834/CHARMM22star/metad_wte/sb_R76_E240_500ns/1D_d1/fes_500.dat 


#### PART1  #### 

#visualize the final fes with gnuplot before doing the plots


#open gnuplot and on the gnuplot terminal write
#the steps below are needed to zoom in in the axis in the region of interest
> plot 'fes_500.dat' u 1:2 w l 
> set yrange [0:15]
> set xrange [0:2]
> replot

#after this you will see your interactive plot with a zoom in and you can start to see the minima of interest. You need also this to define the range for each of the minima of interest.

#notes from the visualization (TO BE REPLACED if you analyze another fes file):
possible minima salt bridge formed  0.35 - 0.5 nm and 0.5-0.7 nm , still deep minima for salt bridge not formed similar to the initial structure: 1.55-1.7 nm

#then use the with gnuplot script plot_fes.pnl and customize it if necessary
#it accounts for conversion to angstrom for the distance and kcal/mol for the f.energy
#detailed comments in the script 
#it will save a eps with the plot that you can check with evince and use to show the fes

