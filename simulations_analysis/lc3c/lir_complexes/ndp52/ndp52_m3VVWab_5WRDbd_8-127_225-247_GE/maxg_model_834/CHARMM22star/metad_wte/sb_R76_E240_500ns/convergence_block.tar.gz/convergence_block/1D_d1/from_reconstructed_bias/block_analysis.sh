#!/bin/bash

# set up your environment
. /usr/local/envs/py37/bin/activate
module load plumed

# directory where the colvar with reconstructed bias is located
rec_bias="../../../reconstructed_bias/"
colvar=${rec_bias}/colvar
# directory with simulation data
# ref_fes is the reference FES calculated with sum_hills
PATHdata="../../../../../../../../../../../../simulations/lc3c/lir_complexes/ndp52/ndp52_m3VVWab_5WRDbd_8-127_225-247_GE/maxg_model_834/CHARMM22star/metad_wte/sb_R76_E240_500ns"
fes_dir=${PATHdata}/1D_d1/
ref_fes=${fes_dir}/"fes_500.dat"

# define the block sizes to be used. Different set-ups / simulations may 
# require different block sizes to be defined here. I've noticed for instance,
# up to 1000 frames for a 10 ns, 10000 frame simulation (10 blocks minimum)
# https://www.plumed.org/doc-master/user-doc/html/trieste-4.html
# up to 1000 frames for a 1us, 100000-frame simulation (100 blocks minimum)
# http://cgmartini.nl/index.php/tutorials-general-introduction-gmx5/metadynamics
# a lesson on block analysis by Giovanni Bussi says to use a bare inimum of 3-5 
# blocks. 
# https://github.com/plumed/lugano2019/blob/master/slides/04-lecture-errors.pdf
# In this case since we have 500k frames I've used up to 150k as blocks size
# which corresponds to around 3 blocks. Mileage may vary.
start_size=1000
end_size=150000
delta_size=1000

# definition of the grid for the CV. You can use similar values as what
# defined in the plumed file. These variables include grid extremes 
# (minium and maximum) and number of bins. Notice that you should tune your
# grid definition so that you don't have Infinity value in the weight files
# (see below), or at least as few as possible. Here I am using 30 bins which
# correspond to ~0.05 A per bin
gridmin=0.25
gridmax=1.8
gridbins=30

# Kb * T - for GROMACS units it should be = temperature (K) * 0.0083144598
kbt=2.5

# check if reconstructed bias colvar is available
if [[ ! -e ${colvar} ]]; then 
	echo "the reconstructed bias colvar file isn't available"
	exit
fi

# find maximum bias value
# check column numbers for cv and bias.
# column 3 ($3) is metad.bias in this case, change according to your case
# of study. Same for CV ($1 here)
bmax=$(awk 'BEGIN{max=0.}{if($1!="#!" && $3>max)max=$3}END{print max}' ${colvar})
echo "max bias is" ${bmax}

# estimate weights
# print cv d1 values and estimate weights
awk '{if($1!="#!") print $2,exp(($3-bmax)/kbt)}' kbt=${kbt} bmax=$bmax ${colvar} > d1.weight

# perform block analysis
rm -f err.blocks
rm -f fes.*.dat

# for each block size
for i in $(seq ${start_size} ${delta_size} ${end_size}); do
        echo "doing block size ${i}"
        # calculate error and plot fes
	# arguments are cv+weight file, number of cvs for fes,
	# min and max grid, number of bin, KbT, block size
	python3 do_block_fes.py d1.weight 1 ${gridmin} ${gridmax} ${gridbins} ${kbt} ${i}
	# calculate average error
	# check if you have Infinity values in these output fes files and change the grid
	# definition accordingly
        echo ${i} $(awk '{tot+=$3}END{print tot/NR}' fes.$i.dat) >> err.blocks
	# plot fes for this block size
	gnuplot  -e "fes=${i}"  plot_fes.pnl
done
# plot average error per block size
gnuplot plot.pnl
# plot comparison between the fes calculated from the largest block and
# the one calculated with sum_hills. Note that this script ignores lines
# with Infinity lines automatically so you don't need to edit your
# fes files
python plot_fes_compare.py fes.${i}.dat ${ref_fes}
