This directory contains the re-estimation of metadynamics bias from an already
completed metadynamics run. It requires 

* a modified version of the original PLUMED file
* the output trajectory of the run (here we use a PBC-resolved one)
* the original HILLS file
* any other accessory file necessary for the run (for instance PDBs as in this
case)
* tested on plumed 2.5.0 (doesn't run on plumed 2.3b!)

the plumed.dat file should be modified as follows respect to the one of the
original run:

- the METAD command should have very high PACE so that no new bias is deposited
- the STRIDE for the PRINT command should be set to 1
- PRINT should also include metad.bias
- RESTART should be on

in order to run the reconstruction just use the included script, after
modifying it to fit your system and set up:

tsp bias_reconstruction.sh

